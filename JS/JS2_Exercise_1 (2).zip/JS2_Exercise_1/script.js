let myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

const posts = [
  {
    text: "Home",
    href: "#"
  },
  {
    text: "About me",
    href: "#"
  },
  {
    text: "My Portfolio",
    href: "#"
  },
  {
    text: "Random Link",
    href: "https://resources.stkfupm.com/vfm-admin/vfm-downloader.php?q=dXBsb2Fkcy9JQ1MvSUNTMzUzL2VCb29rcyUyMCUyNiUyMFNvbHV0aW9uJTIwTWFudWFscy9JQ1MzNTNfX0UtQm9va19fQWxzdXdhaXllbC0tLURlc2lnbi10ZWNobmlxdWVzLWFuZC1hbmFseXNpcy0lMjhSZXZpc2VkJTI5LnBkZg==&h=cba0b7d5b9b748a1b04fe88e1098e58f"
  },
];

let fo = document.querySelector("footer");
console.log(fo)
for(let things of posts)  {
  let idk = document.createElement("a")
  idk.innerText = things.text
  idk.href = things.href
  fo.prepend(idk)
}
