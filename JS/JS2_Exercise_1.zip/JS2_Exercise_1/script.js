let myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

let p_tag = document.createElement("p")

p_tag.className = "special"

p_tag.innerHTML = "Room prices are fixed, and are after taxes."

document.body.appendChild(p_tag)