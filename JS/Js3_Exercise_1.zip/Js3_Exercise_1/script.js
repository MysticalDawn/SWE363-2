let myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

async function cats(){
  const response = await fetch("https://api.thecatapi.com/v1/images/search")
  let the_image = await response.json()
  the_image = JSON.stringify(the_image)
  the_image = the_image.substring(1, the_image.length - 1)
  the_image = JSON.parse(the_image)

  console.log(the_image.url)
  doIt(the_image.url)
}

cats()

function doIt(url) {
  // create h1 tag
  const h1 = document.createElement('h1')
  h1.innerHTML = 'Cat Generator using fetch'
  h1.setAttribute('style', 'text-align: center; font-size: 50px; margin-top: 100px; margin-bottom: 100px; font-family: Raleway;')

  const img = document.createElement('img')
  img.setAttribute('width', '600')
  img.setAttribute('height', '400')
  // center the img
  img.setAttribute('style', 'display: block; margin-left: auto; margin-right: auto;')
  // make the img border radius
  img.setAttribute('style', 'border-radius: 50%;')
  img.src = url

  // create a button
  const button = document.createElement('button')
  button.setAttribute('style', 'display: block; margin-left: auto; margin-right: auto;')
  button.innerHTML = 'New Cat'

  // make the img and the button go up
  const div = document.createElement('div')
  div.setAttribute('style', 'display: flex; flex-direction: column; justify-content: center; align-items: center; margin-bottom: 200px; ')
  div.appendChild(img)
  div.appendChild(button)
  div.appendChild(h1)
  document.getElementById('body').appendChild(div)

  // if the button is clicked, remove the old img and the button and create a new one
  button.addEventListener('click', () => {
    div.removeChild(img)
    div.removeChild(button)
    div.removeChild(h1)
    cats()
  })

}