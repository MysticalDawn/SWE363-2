
const numbers = [21, 14, 1, 64, 3, 6, 7, 9, 10, 11, 12, 13, 14, 15];

const multiplyByThree = (arr) => arr.map((num) => num * 3);

const getEvenNumbers = (arr) => arr.filter((num) => num % 2 === 0);

const getSumOfNumbers = (arr) => arr.reduce((acc, num) => acc + num);

const result = multiplyByThree(numbers);
console.log(result);
const result2 = getEvenNumbers(result);
console.log(result2);
const result3 = getSumOfNumbers(result2);
console.log(result3);

