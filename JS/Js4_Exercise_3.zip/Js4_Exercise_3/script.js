// create a function that utilizes array functions: map, reduce, filter and make them connected to each other

// 1. Create an array of numbers
const numbers = [21, 14, 1, 64, 3, 6, 7, 9, 10, 11, 12, 13, 14, 15];

// 2. Create a function that takes an array of numbers and returns a new array with each number multiplied by 2
const multiplyByThree = (arr) => arr.map((num) => num * 3);

// 3. Create a function that takes an array of numbers and returns only the even values

const getEvenNumbers = (arr) => arr.filter((num) => num % 2 === 0);

// 4. Create a function that takes an array of numbers and returns the sum of all the numbers
const getSumOfNumbers = (arr) => arr.reduce((acc, num) => acc + num);

// 5. Call each function with the numbers array and chain them, log the result
const result = multiplyByThree(numbers);
console.log(result);
const result2 = getEvenNumbers(result);
console.log(result2);
const result3 = getSumOfNumbers(result2);
console.log(result3);

