let turn = "X";
let gameEnded = false;
let moves = 0;
const cells = document.querySelectorAll(".cell");
let board = document.getElementsByClassName("board")[0];

(() => {
  console.log("IIFE");
})();

const addLetter = (cell) => {
  cell.innerText = turn;
  cell.classList.add("selected");
};

const winner = () => {
  const wins = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  continueWins(wins);
};

const continueWins = (wins) => {
  wins.forEach((win) => {
    let selected = win.map((i) => cells[i]);
    if (selected.every((cell) => cell.innerText === turn) && !gameEnded) {
      document.querySelector("#turn").innerText = `${turn} Wins!`;
      gameEnded = true;
      setInterval(() => {
        location.reload();
      }, 1500);
    }
  });
};

const turnTog = () => {
  turn = turn === "X" ? "O" : "X";
  document.querySelector("#turn span").innerText = turn;
};

const checkDraw = () => {
  if (moves === 9 && !gameEnded) {
    document.querySelector("#turn").innerText = "Draw!";
    gameEnded = true;
    setInterval(function () {
      location.reload();
    }, 1500);
  }
};

document
  .getElementById("but")
  .addEventListener("click", () => location.reload());

board.addEventListener("click", (event) => {
  const cell = event.target;

  if (!cell.classList.contains("selected") && !gameEnded) {
    addLetter(cell);
    moves += 1;
    winner();
    turnTog();
    checkDraw();
  }
});
