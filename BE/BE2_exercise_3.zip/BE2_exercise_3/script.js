const process = require("process");
const questions = [
  "What is your name?",
  "What would you rather be doing?",
  "What is your preferred programming language?",
];

const answers = [
  "My name is John",
  "I would rather be sleeping",
  "My preferred programming language is JavaScript",
];

process.stdin.on("readable", () => {
  let itertate;
  while ((itertate = process.stdin.read()) !== null) {
    let input_user = itertate.toString().trim();
    if (input_user === "exit" || input_user === "quit") {
      process.exit(0);
    } else {
      if (questions.includes(input_user)) {
        console.log(answers[questions.indexOf(input_user)]);
      } else {
        console.log("I don't understand your question");
      }
    }
  }
});
