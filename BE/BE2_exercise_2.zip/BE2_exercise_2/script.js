const fs = require("fs");

const data = fs.readdir("./", (err, data) => {
  if (err) {
    console.log("Error: ", err);
  } else {
    data = data.filter((file) => file.endsWith('.txt') || file.endsWith('.jpg'))
    data.forEach((file) => {
      fs.copyFile(file, `./newTest/${file}`, (err) => {
        if (err) {
          console.log("Error: ", err);
        } else {
          console.log("Copied file: ", file);
        }
      });
    });

  }
});
