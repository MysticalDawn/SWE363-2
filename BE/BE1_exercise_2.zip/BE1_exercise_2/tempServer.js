const temp = require("http-server")
const server = temp.createServer()
server.listen(2, () => {
    console.log("Server is running at 2")
})