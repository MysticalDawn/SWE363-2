const EventEmitter = require("events");
const min = 0.2;
const max = 2;
let randomNum = 0;
const eventEmitter = new EventEmitter();
changeTimer();
function changeTimer() {
  randomNum = Math.random() * (max - min) + min;
  setTimeout(() => {
    if (randomNum > 0.9) {
      eventEmitter.emit("login");
    } else {
      eventEmitter.emit("logout");
    }
  }, randomNum * 1000);
}

eventEmitter.on("login", () => {
  const date = new Date();
  console.log(`${date.getTime()}:User logged in`);
  changeTimer();
});

eventEmitter.on("logout", () => {
  const date = new Date();
  console.log(`${date.getTime()}:User logged out`);
  changeTimer();
});
